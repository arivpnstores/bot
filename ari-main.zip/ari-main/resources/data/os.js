/**
 *  The MIT License (MIT)
 *  Copyright (c) 2024 by @xyzendev - Adriansyah
 *  © 2024 by @xyzendev - Muhammad Adriansyah | MIT License
 */

export default {
    ubuntu: [
        'ubuntu-24-04-x64',
        'ubuntu-23-10-x64',
        'ubuntu-22-04-x64',
        'ubuntu-20-04-x64'
    ],
    debian: [
        'debian-10-x64',
        'debian-11-x64',
        'debian-12-x64'
    ]
}
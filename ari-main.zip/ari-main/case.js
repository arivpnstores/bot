/**
 *  The MIT License (MIT)
 *  Copyright (c) 2024 by @xyzendev - Adriansyah
 *  © 2024 by @xyzendev - Muhammad Adriansyah | MIT License
 */

import { appenTextMessage } from "./core/serialize.js";
import { config } from "./core/index.js";
import { chalk, fs, util } from "@xyzendev/modules/core/main.modules.js";
import { sleep } from "./core/function.js";
import { fileURLToPath } from "url"
import info from "./resources/data/index.js"
import { createdDroplet, infoAccount, restartTheDroplet, deleteTheDroplet, getInfoDroplet, getInfoDropletAll, turnDroplet } from "./resources/digitalocean.js"
/**
 * 
 * @param {*} client 
 * @param {*} store 
 * @param {*} m 
 * @param {*} chatUpdate 
 * @returns 
 */
export default async function Message(client, store, m, chatUpdate) {
    try {
        await (m.type === 'conversation') ? m.message.conversation : (m.type == 'imageMessage') ? m.message.imageMessage.caption : (m.type == 'videoMessage') ? m.message.videoMessage.caption : (m.type == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.type == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.type == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.type == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.type == 'interactiveResponseMessage') ? appenTextMessage(JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id, chatUpdate, m, client) : (m.type == 'templateButtonReplyMessage') ? appenTextMessage(m.msg.selectedId, chatUpdate, m, client) : (m.type === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ''
        const quoted = m.isQuoted ? m.quoted : m
        const Downloaded = async (fileName) => await client.downloadMediaMessage(quoted, fileName)
        const isCommand = (m.prefix && m.body.startsWith(m.prefix)) || false

        if (!m.public) {
            if (!m.key.fromMe || m.isCreator) return;
        }

        if (m.isBot) return;

        if (m.message && !m.isBot) {
            const a = m.isGroup ? "👥 Group" : "👤 Private";
            const b = m.body || m.type;
            console.log(
                `${chalk.blue("FROM")}: ${chalk.yellow(m.pushName + " => " + m.sender)}\n` +
                `${chalk.blue("IN")}: ${chalk.magenta(a)}\n` +
                `${chalk.blue("MESSAGE")}: ${chalk.green(b)}\n` +
                `🕒 ${new Date().toLocaleTimeString()}`
            );
        }

        switch (isCommand ? m.command.toLowerCase() : false) {
            case 'menu': {
                const menu = {
                    main: ["bcgroup"],
                    digitalocean: ["createvps", 'cekiddroplet', "deletedroplet", 'restartdroplet', 'turnoff', 'turnon', "sisadroplet"]
                }
                let txt = ""
                Object.keys(menu).forEach((category) => {
                    txt += `\n*${category.toUpperCase()}*\n`;
                    menu[category].forEach((item, index) => {
                        txt += `${index + 1}. ${m.prefix}${item}\n`;
                    });
                });
                m.reply(txt)
            }
                break
            case 'bcgc':
            case 'bcgroup': {
                if (!m.isCreator) return m.reply('Only Owner')
                if (!m.text) return m.reply('Teksnya Mana??');
                let getGroups = await client.groupFetchAllParticipating()
                let groups = Object.entries(getGroups).slice(0).map(entry => entry[1])
                let anu = groups.map(v => v.id)
                m.reply('please wait...')
                for (let i of anu) {
                    await sleep(5000)
                    await client.sendMessage(i, { text: m.text })
                }
                m.reply('done')
            }
                break

            case "ceksisadroplet":
            case 'sisadroplet': {
                if (!m.isCreator) return m.reply('Only Owner')
                const { account } = await infoAccount()
                const data = await getInfoDropletAll()
                const drop = account.droplet_limit - data.length
                m.reply(`Sisa Droplet: ${drop}`)
            }
                break
            case 'createvps':
            case 'cvps': {
                const Types = info.Type;
                const sections = [];
                Object.keys(Types).map(async (key) => {
                    const typeData = Types[key];
                    const section = {
                        title: `Vps Type ${key}`,
                        highlight_label: "Rekomendasi",
                        rows: []
                    };
                    typeData.forEach((config) => {
                        section.rows.push({
                            title: config.toUpperCase(),
                            description: '',
                            id: "." + config,
                        });
                    });
                    sections.push(section);
                });
                await client.sendList(m.from, 'Pilih Type VPS', 'Powered By Adrian', {
                    title: "Type VPS",
                    sections: sections
                });
            }
                break;

            case 's-1vcpu-512mb-10gb':
            case 's-1vcpu-1gb':
            case 's-1vcpu-2gb':
            case 's-2vcpu-2gb':
            case 's-2vcpu-4gb':
            case 's-4vcpu-8gb':
            case 's-1vcpu-1gb-35gb-intel':
            case 's-1vcpu-2gb-70gb-intel':
            case 's-2vcpu-2gb-90gb-intel':
            case 's-2vcpu-4gb-120gb-intel':
            case 's-4vcpu-8gb-240gb-intel':
            case 's-1vcpu-1gb-amd':
            case 's-1vcpu-2gb-amd':
            case 's-2vcpu-2gb-amd':
            case 's-2vcpu-4gb-amd':
            case 's-4vcpu-8gb-amd': {
                if (!m.isCreator) return m.reply('Only Owner')
                let droplet = await createdDroplet(m.body.replace(/\./g, ''))
                m.reply('please wait... 1 minute')
                await new Promise(resolve => setTimeout(resolve, 60000));
                const a = await getInfoDroplet(droplet.data.droplet.id)
                const ip = a.droplet.networks.v4[0].ip_address
                const name = a.droplet.name
                const size = a.droplet.size_slug
                const image = a.droplet.image.slug
                const status = a.droplet.status.toUpperCase()
                const text = `Name: ${name}\nIP: ${ip}\nSize: ${size}\nImage: ${image}\nStatus: ${status}\nPassword: ${droplet.pass}`
                m.reply(text)
            }
                break
            case 'cekid':
            case 'cekiddroplet':
            case 'infoid': {
                if (!m.isCreator) return m.reply('Only Owner')
                const res = await getInfoDropletAll()
                let txt = ""
                for (const droplet of res) {
                    txt += "====================================\n"
                    txt += `- ID Droplets: ${droplet.id}\n`
                    txt += `- Name: ${droplet.name}\n`
                    txt += `- IP Address: ${droplet.networks.v4[0].ip_address}\n`
                    txt += "- Username: root\n"
                    txt += `- Memory: ${droplet.memory} MB\n`
                    txt += `- VCPUs: ${droplet.vcpus} Cpuz\n`
                    txt += `- Disk: ${droplet.disk} GB\n`
                    txt += `- Status: *${droplet.status.toUpperCase()}*\n`
                    txt += "====================================\n\n"
                }
                await client.sendMessage(m.from, {
                    text: txt,
                    contextInfo: {
                        forwardingScore: 999,
                        isForwarded: true,
                        mentionedJid: [m.sender],
                        forwardedNewsletterMessageInfo: {
                            newsletterName: "Powered By Adrian",
                            newsletterJid: "120363182916458068@newsletter"
                        },
                        externalAdReply: {
                            title: "The List of Droplets",
                            body: '',
                            thumbnailUrl: "https://blog.speedvitals.com/wp-content/uploads/2021/08/Digitalocean-Banner.png.jpg",
                            showAdAttribution: true,
                            renderLargerThumbnail: true,
                            mediaType: 1
                        }
                    }
                }, { quoted: m })
            }
                break
            case 'deletedroplet':
            case 'deldroplet': {
                if (!m.isCreator) return m.reply('Only Owner');

                const idDroplet = await getInfoDropletAll();
                const id = idDroplet.map(droplet => ({
                    title: droplet.name.toUpperCase(),
                    description: "ID:" + droplet.id.toString(),
                    id: ".deldrop " + droplet.id
                }));

                const sections = [{
                    title: "Pilih Droplet",
                    rows: id
                }];

                await client.sendList(m.from, 'Pilih Droplet Yang Mau Didelete', 'Powered By Adrian', {
                    title: "Droplet List",
                    sections: sections
                });
            }
                break;
            case 'deldrop': {
                if (!m.isCreator) return m.reply('Only Owner');
                await deleteTheDroplet(m.text).then(() => {
                    m.reply('Droplet Deleted')
                }).catch(() => {
                    m.reply('Droplet Not Found')
                })
            }
                break

            case 'restartdroplet': {
                if (!m.isCreator) return m.reply('Only Owner');
                const idDroplet = await getInfoDropletAll();

                const id = idDroplet.map(droplet => ({
                    title: droplet.name.toUpperCase(),
                    description: "ID: " + droplet.id.toString(),
                    id: ".resdrop " + droplet.id
                }));

                const sections = [{
                    title: "Pilih Droplet",
                    rows: id
                }];

                await client.sendList(m.from, 'Pilih Droplet Yang Mau Di Restart', 'Powered By Adrian', {
                    title: "Droplet List",
                    sections: sections
                });
            }
                break
            case 'resdrop': {
                if (!m.isCreator) return m.reply('Only Owner');
                await restartTheDroplet(m.text).then(() => {
                    m.reply('Droplet Restarted')
                }).catch(() => {
                    m.reply('Droplet Not Found')
                })
            }
                break
            case 'turnoff': {
                if (!m.isCreator) return m.reply('Only Owner');
                const idDroplet = await getInfoDropletAll();

                const id = idDroplet.map(droplet => ({
                    title: droplet.name.toUpperCase(),
                    description: "ID: " + droplet.id.toString(),
                    id: ".turnoffdrop " + droplet.id
                }));
                const sections = [{
                    title: "Pilih Droplet",
                    rows: id
                }];
                await client.sendList(m.from, 'Pilih Droplet Yang Mau Di Matikan', 'Powered By Adrian', {
                    title: "Droplet List",
                    sections: sections
                });
            }
                break
            case 'turnoffdrop': {
                if (!m.isCreator) return m.reply('Only Owner');
                await turnDroplet(m.text, 'power_off').then(() => {
                    m.reply('Droplet Turned Off')
                }).catch(() => {
                    m.reply('Droplet Not Found')
                })
            }
                break
            case 'turnon': {
                if (!m.isCreator) return m.reply('Only Owner');
                const idDroplet = await getInfoDropletAll();
                const id = idDroplet.map(droplet => ({
                    title: droplet.name.toUpperCase(),
                    description: "ID: " + droplet.id.toString(),
                    id: ".turnondrop " + droplet.id
                }));

                const sections = [{
                    title: "Pilih Droplet",
                    rows: id
                }];
                await client.sendList(m.from, 'Pilih Droplet Yang Mau Di Nyalakan', 'Powered By Adrian', {
                    title: "Droplet List",
                    sections: sections
                });
            }
                break
            case 'turnondrop': {
                if (!m.isCreator) return m.reply('Only Owner');
                await turnDroplet(m.text, 'power_off').then(() => {
                    m.reply('Droplet Turned Off')
                }).catch(() => {
                    m.reply('Droplet Not Found')
                })
            }
                break
            default:
                if (['>', 'eval', '=>'].some(a => m.command.toLowerCase().startsWith(a)) && m.isCreator) {
                    let evalCmd = '';
                    try {
                        evalCmd = /await/i.test(m.text) ? eval('(async() => { ' + m.text + ' })()') : eval(m.text);
                    } catch (e) {
                        evalCmd = e;
                    }
                    new Promise((resolve, reject) => {
                        try {
                            resolve(evalCmd);
                        } catch (err) {
                            reject(err);
                        }
                    })
                        ?.then(res => m.reply(util.format(res)))
                        ?.catch(err => m.reply(util.format(err)));
                }
        }
    } catch (e) {
        client.sendMessage(config.owners + "@s.whatsapp.net", { text: "`" + util.format(e) + "`" }, { quoted: m })
        console.error(e)
    }
}

let fileP = fileURLToPath(import.meta.url);
fs.watchFile(fileP, () => {
    fs.unwatchFile(fileP);
    console.log(`Successfully To Update File ${fileP}`)
})
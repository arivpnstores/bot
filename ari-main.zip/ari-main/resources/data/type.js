/**
 *  The MIT License (MIT)
 *  Copyright (c) 2024 by @xyzendev - Adriansyah
 *  © 2024 by @xyzendev - Muhammad Adriansyah | MIT License
 */

export default {
    regular: [
        's-1vcpu-512mb-10gb',
        's-1vcpu-1gb',
        's-1vcpu-2gb',
        's-2vcpu-2gb',
        's-2vcpu-4gb',
        's-4vcpu-8gb'
    ],
    itel: [
        's-1vcpu-1gb-35gb-intel',
        's-1vcpu-2gb-70gb-intel',
        's-2vcpu-2gb-90gb-intel',
        's-2vcpu-4gb-120gb-intel',
        's-4vcpu-8gb-240gb-intel'
    ],
    amd: [
        's-1vcpu-1gb-amd',
        's-1vcpu-2gb-amd',
        's-2vcpu-2gb-amd',
        's-2vcpu-4gb-amd',
        's-4vcpu-8gb-amd'
    ]
}
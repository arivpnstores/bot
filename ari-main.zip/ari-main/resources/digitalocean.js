/**
 *  The MIT License (MIT)
 *  Copyright (c) 2024 by @xyzendev - Adriansyah
 *  © 2024 by @xyzendev - Muhammad Adriansyah | MIT License
 */

import axios from "axios";
import config from "../config.js"
import { randomBytes } from "crypto";

const api = config.api.do


export async function createdDroplet(size, region = 'sgp1', image = "ubuntu-20-04-x64") {
    const pass = await randomBytes(6).toString('hex')
    const body = {
        name: `xyzen-${randomBytes(4).toString('hex')}`,
        region,
        size,
        image,
        ssh_keys: null,
        backups: false,
        ipv6: false,
        user_data: `#cloud-config
password: ${pass}
chpasswd: { expire: False }`,
        private_networking: null,
        volumes: null,
        tags: ['xyzen'],
    }
    const { data } = await axios.post("https://api.digitalocean.com/v2/droplets", body, {
        headers: {
            'Content-Type': 'application/json',
            "Authorization": "Bearer " + api
        },
        maxBodySize: Infinity,
    })

    return { data, pass }
}


export async function turnDroplet(id, state) {
    const response = await axios.post(
        `https://api.digitalocean.com/v2/droplets/${id}/actions`,
        { type: state },
        {
            headers: {
                'Content-Type': 'application/json',
                Authorization: `Bearer ${api}`,
            },
            maxRedirects: 0,
        }
    );
    return response.data
}
export async function infoAccount() {
    const { data } = await axios.get('https://api.digitalocean.com/v2/account', {
        headers: {
            'Authorization': `Bearer ${api}`
        },
        maxBodySize: Infinity,
        responseType: 'json',
        timeout: 3000
    })

    return data
}

export async function restartTheDroplet(id) {
    const { data } = await axios.patch(
        `https://api.digitalocean.com/v2/droplets/${id}`,
        { "type": "reboot" },
        { headers: { 'Content-Type': 'application/json', "Authorization": `Bearer ${api}` } }
    )
    return data
}


export async function rebuildTheDroplet(id, image = "ubuntu-20-04-x64") {
    const { data } = await axios.patch(
        `https://api.digitalocean.com/v2/droplets/${id}`,
        { type: 'rebuild', image },
        { headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${api}` }, timeout: 3000 }
    )

    return data
}


export async function deleteTheDroplet(id) {
    const res = await axios.delete(`https://api.digitalocean.com/v2/droplets/${id}`, {
        headers: {
            'Content-Type': 'application/json',
            "Authorization": "Bearer " + api
        },
        timeout: 10000
    })
    return res.status === 204
}


export async function getInfoDroplet(id) {
    const res = await axios.get(`https://api.digitalocean.com/v2/droplets/${id}`, {
        headers: {
            'Content-Type': 'application/json',
            "Authorization": "Bearer " + api
        },
        timeout: 10000
    })
    return res.data
}

export async function getInfoDropletAll() {
    const { data } = await axios.get("https://api.digitalocean.com/v2/droplets", {
        headers: {
            'Content-Type': 'application/json',
            "Authorization": "Bearer " + api
        },
        params: { limit: 100 },
        timeout: 10000,
    })

    const getRemaining = async ({ currentPage = 1, totalRows = 0 } = {}) => {
        const chunks = Math.ceil(totalRows / 100)
        const fetched = new Set(data.droplets.map(d => d.id))
        const remaining = Array.from({ length: chunks }, (_, i) => i + currentPage + 1)
            .filter(page => page <= Math.ceil(totalRows / 100))
            .map(async page => {
                const res = await axios.get(`https://api.digitalocean.com/v2/droplets`, {
                    headers: {
                        'Content-Type': 'application/json',
                        "Authorization": "Bearer " + api
                    },
                    params: {
                        limit: 100,
                        page,
                    },
                    timeout: 10000,
                })

                return res.data.droplets.filter(d => !fetched.has(d.id))
            })

        return Promise.all(remaining).then(flattened => [...data.droplets, ...Array.prototype.flat(flattened)])
    }

    return await getRemaining()
}

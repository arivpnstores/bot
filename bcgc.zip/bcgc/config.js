/**
 *  The MIT License (MIT)
 *  Copyright (c) 2024 by @xyzendev - Adriansyah
 *  © 2024 by @xyzendev - Muhammad Adriansyah | MIT License
 */

export default {
    self: false,
    usePairing: true,
    write_store: false,
    owners: ["6281327393959"],
    bot: "6281327393959"
}
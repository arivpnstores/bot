/**
 *  The MIT License (MIT)
 *  Copyright (c) 2024 by @xyzendev - Adriansyah
 *  © 2024 by @xyzendev - Muhammad Adriansyah | MIT License
 */

import os from "./os.js";
import region from "./region.js";
import Type from "./type.js";

export default {
    os,
    region,
    Type
}
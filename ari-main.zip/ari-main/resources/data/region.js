/**
 *  The MIT License (MIT)
 *  Copyright (c) 2024 by @xyzendev - Adriansyah
 *  © 2024 by @xyzendev - Muhammad Adriansyah | MIT License
 */

export default {
    nyc: [
        'nyc1',
        'nyc2',
        'nyc3',
    ],
    sfo: [
        'sfo1',
        'sfo2',
        'sfo3',
    ],
    ams: [
        'ams1',
        'ams2',
        'ams3',
    ],
    sgp: 'sgp1',
    lon: 'lon1',
    fra: 'fra1',
    tor: 'tor1',
    blr: 'blr1',
    syd: 'syd1'
}
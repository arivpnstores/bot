/**
 *  The MIT License (MIT)
 *  Copyright (c) 2024 by @xyzendev - Adriansyah
 *  © 2024 by @xyzendev - Muhammad Adriansyah | MIT License
 */

export default {
    self: false,
    usePairing: true,
    write_store: false,
    owners: ["6281327393959"],
    bot: "62859106963745",
    api: {
        do: "dop_v1_22d3ed7f0edddffcffb3317a104e3ac0592f9a50af188f487e434ae4dffce00f"
    }
}
//base by DGXeon
//re-upload? recode? copy code? give credit ya :)
//YouTube: @DGXeon
//Instagram: unicorn_xeon13
//Telegram: t.me/xeonbotinc
//GitHub: @DGXeon
//WhatsApp: +6285789987714
//want more free bot scripts? subscribe to my youtube channel: https://youtube.com/@DGXeon

const fs = require('fs')
const chalk = require('chalk')

//owmner v card
global.ytname = "YT:@maourafa9999"//ur yt chanel name
global.socialm = "IG:@maourafa" //ur github or insta name
global.location = "Indonesia" //ur location

//new
global.botname = '魔王ｍａｏｕｒａｆａ|ᵇᵒᵗ' //ur bot name
global.ownernumber = '6285789987714' //ur owner number
global.ownername = 'maourafa' //ur owner name
global.websitex = "https://youtu.be/@maourafa9999"
global.wagc = "https://chat.whatsapp.com/FLOx2CoKCjYFQFL9ZXGwfz"
global.themeemoji = '🪀'
global.wm = "魔王ｍａｏｕｒａｆａ|ᵇᵒᵗ number: 6282278687542"
global.botscript = '`Im sorry this link is not anivable`' //script link
global.packname = "BOT.Stiker maker by"
global.author = "魔王ｍａｏｕｒａｆａ|ᵇᵒᵗ \n\nowner : +6285789987714\nbot       : +6282278687542"
global.creator = "6285789987714@s.whatsapp.net"
global.xprefix = '.','#','!','?','help'
global.premium = ["6285789987714"] // Premium User
global.hituet = 0

//bot sett
global.typemenu = 'v4' // menu type 'v1' => 'v8'
global.typereply = 'v3' // reply type 'v1' => 'v3'
global.autoblocknumber = '92' //set autoblock country code
global.antiforeignnumber = '91' //set anti foreign number country code
global.welcome = true //welcome/left in groups
global.anticall = false //bot blocks user when called
global.autoswview = true //auto status/story view
global.adminevent = true //show promote/demote message
global.groupevent = true //show update messages in group chat
//msg
global.mess = {
	limit: 'Your limit is up!',
	nsfw: 'Nsfw is disabled in this group, Please tell the admin to enable',
    done: 'Done✓',
    error: 'Error!',
    success: 'Ini dia,terima kasih telah menunggu'
}
//thumbnail
global.thumb = fs.readFileSync('./XeonMedia/theme/cheemspic.jpg')

let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(chalk.redBright(`Update'${__filename}'`))
    delete require.cache[file]
    require(file)
})